#pragma once

#include "VirtualMethod.h"

class MDLCache
{
public:
	VIRTUAL_METHOD(void, beginLock, 33, (), (this))
	VIRTUAL_METHOD(void, endLock, 34, (), (this))
};