#pragma once

namespace Fakelag
{
    void run(bool& sendPacket) noexcept;
}