#pragma once

struct UserCmd;

namespace Knifebot
{
    void run(UserCmd*) noexcept;
}